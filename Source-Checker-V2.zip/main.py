import requests
import lxml
import ipaddress
import socket   
hostname = socket.gethostname()    
IPAddr = socket.gethostbyname(hostname)   
r = requests.get("http://patorjk.com/software/taag/#p=display&f=Thick&t=ok%20boomer")

f = open('your-source-code.txt','a')
f.write('\n')

f.write('\n' + hostname)
f.write('\n')
f.write('\n')
f.write('\n' + r.text)
f.close()
print("Source Code Check Successful")