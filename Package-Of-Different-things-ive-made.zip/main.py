import time
from colorama import Fore, Back, Style 
import getpass
import calendar
import sys
import hashlib
import webbot
import os
import random
import requests
import lxml
import ipaddress
import socket
import sys


def delay_print(s):
    for c in s:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.1)

def delay_printf(s):
    for c in s:
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0.01)

hostname = socket.gethostname()    
IPAddr = socket.gethostbyname(hostname)  
epochtoutc = time.gmtime()


def opt_1():
  print("Your IP Address is: " + IPAddr)

def opt_2():
  delay_print("Shutting Down...")
  print("")
  print("")
  delay_printf(Fore.BLUE + " ██████╗  ██████╗  ██████╗ ██████╗ ██████╗ ██╗   ██╗███████╗")
  print("")
  time.sleep(0.1)
  delay_printf(Fore.GREEN + "██╔════╝ ██╔═══██╗██╔═══██╗██╔══██╗██╔══██╗╚██╗ ██╔╝██╔════╝")
  time.sleep(0.1)
  print("")
  delay_printf(Fore.YELLOW + "██║  ███╗██║   ██║██║   ██║██║  ██║██████╔╝ ╚████╔╝ █████╗  ")
  time.sleep(0.1)
  print("")
  delay_printf(Fore.RED + "██║   ██║██║   ██║██║   ██║██║  ██║██╔══██╗  ╚██╔╝  ██╔══╝  ")
  time.sleep(0.1)
  print("")
  delay_printf(Fore.BLUE + "╚██████╔╝╚██████╔╝╚██████╔╝██████╔╝██████╔╝   ██║   ███████╗")
  time.sleep(0.1)
  print("")
  delay_print(" ╚═════╝  ╚═════╝  ╚═════╝ ╚═════╝ ╚═════╝    ╚═╝   ╚══════╝")
  print("")
  quit()
  

    

 
  
def opt_3():
  print("Opening Browser. . .")

def opt_4():
  print("Your Host Name is: " + hostname)

def opt_3866():
  print("Hello. You Have found the dev screen. If you are not here on purpose, then please leave. if not, ")
  print("if not,")
  time.sleep(0.1)
  print("if not,")
  time.sleep(0.1)
  print("if not,")
  time.sleep(0.1)
  print("if not,")
  time.sleep(0.1)
  print("if not,")
  time.sleep(0.1)
  delay_print("printexeption_403_programcodenotfound_line24")
  quit()

def invalid_opt():
  print(Fore.RED + "Invalid Program" + Style.RESET_ALL)
  print("Please Run Again")

options = {"1":["Check My IP",opt_1], "2":["Shut Down",opt_2],  "3":["Run Browser", opt_3],  "4":["Check Hostname", opt_4]}

for option in options:
  print(option+") "+options.get(option)[0])

choice = input("Please make Your choice: ")

val = options.get(choice)
if val is not None:
  action = val[1]
else:
  action = invalid_opt

action()